<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
<key>items</key>
<array>
<dict>
<key>assets</key>
<array>
<dict>
<key>kind</key>
<string>software-package</string>
<key>url</key>
<string> https://archive.org/download/apps-manager-1.7-1663550643/Apps%20Manager_1.7_1663550643.ipa </string>
</dict>
</array>
<key>metadata</key>
<dict>
<key>bundle-identifier</key>
<string>com.ខំមែសប្រូឈឺណាមើល</string>
<key>bundle-version</key>
<string>19.3.0</string>
<key>kind</key>
<string>software</string>
<key>title</key>
<string>ខំមែសប្រូឈឺណាមើល</string>
</dict>
</dict>
</array>
</dict>
